package com.bt.ms.im;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroServicesApplication {

  public static void main(String[] args) {

    SpringApplication.run(MicroServicesApplication.class, args);
  }
}
