package com.bt.ms.im.repository;

public class SampleTestClass {

}
