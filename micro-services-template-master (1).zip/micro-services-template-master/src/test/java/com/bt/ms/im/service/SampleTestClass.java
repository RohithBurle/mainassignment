package com.bt.ms.im.service;

public class SampleTestClass {

}
