package com.bt.ms.im.controller;

public class SampleTestClass {

}
