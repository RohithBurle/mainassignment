package com.bt.ms.im.mapper;

public class SampleTestClass {

}
