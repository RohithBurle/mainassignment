package com.bt.ms.im.exception.handler.standardexception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.bt.ms.im.exception.StandardError;

@ResponseStatus(HttpStatus.UNAUTHORIZED)
public class UnauthorizedException extends StandardException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4398406204187390510L;

	public UnauthorizedException(StandardError errorCode, Throwable cause) {
		super(errorCode, cause);
		// TODO Auto-generated constructor stub
	}

	public UnauthorizedException(StandardError errorCode) {
		super(errorCode);
		// TODO Auto-generated constructor stub
	}

	public UnauthorizedException(String code,String  msg) {
		super(code,msg);
		// TODO Auto-generated constructor stub
	}
	
}
