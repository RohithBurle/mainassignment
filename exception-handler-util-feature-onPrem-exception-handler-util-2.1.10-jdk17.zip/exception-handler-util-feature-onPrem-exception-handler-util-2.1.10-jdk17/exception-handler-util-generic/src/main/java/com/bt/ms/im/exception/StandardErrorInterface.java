package com.bt.ms.im.exception;

public interface StandardErrorInterface {

	String getCode();

	String getMessage();

}