package com.bt.ms.im.exception.handler.standardexception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.bt.ms.im.exception.StandardError;

@ResponseStatus(HttpStatus.FORBIDDEN)
public class ForbiddenException extends StandardException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8830993703167260524L;

	public ForbiddenException(StandardError errorCode, Throwable cause) {
		super(errorCode, cause);
		// TODO Auto-generated constructor stub
	}

	public ForbiddenException(StandardError errorCode) {
		super(errorCode);
		// TODO Auto-generated constructor stub
	}

	public ForbiddenException(String code,String  msg) {
		super(code,msg);
		// TODO Auto-generated constructor stub
	}
	
}
