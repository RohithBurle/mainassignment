package com.bt.ms.im.exception;

public enum StandardError implements StandardErrorInterface {

	ERR503_05 ("05", "The service is temporarily unavailable"),
	ERR503_06 ("06", "Over capacity – retry later"),
	ERR400_20 ("20", "Invalid URL parameter value"),
	ERR400_21 ("21", "Missing body"),
	ERR400_22 ("22", "Invalid body"),
	ERR400_23 ("23", "Missing body field"),
	ERR400_24 ("24", "Invalid body field"),
	ERR400_25 ("25", "Missing header"),
	ERR400_26 ("26", "Invalid header value"),
	ERR400_27 ("27", "Missing query-string parameter"),
	ERR400_28 ("28", "Invalid query-string parameter value"),
	ERR400_29 ("29", "Bad request"),
	ERR403_53 ("53", "Too many requests"),
	ERR404_60 ("60", "Resource not found"),
	ERR405_61 ("61", "Method not allowed"),
	ERR406_62 ("62", "Not acceptable"),
	ERR408_63 ("63", "Request time-out"),
	ERR411_64 ("64", "Length required"),
	ERR412_65 ("65", "Precondition failed"),
	ERR413_66 ("66", "Request entity too large"),
	ERR414_67 ("67", "Request-URI too long"),
	ERR415_68 ("68", "Unsupported Media Type");
	

    private final String errorCode;
    private final String errorMessage;

    private StandardError(String errorCode, String errorMessage) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    /* (non-Javadoc)
	 * @see com.bt.ms.im.exception.ErrorInterface#getCode()
	 */
    @Override
    public String getCode() {
        return errorCode;
    }

    /* (non-Javadoc)
	 * @see com.bt.ms.im.exception.ErrorInterface#getMessage()
	 */
    @Override
    public String getMessage() {
        return errorMessage;
    }
}

