package com.bt.ms.im.exception.handler.standardexception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.bt.ms.im.exception.StandardError;
import com.bt.ms.im.exception.StandardErrorInterface;

@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
public class InternalServerException extends StandardException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4717696477801388243L;

	public InternalServerException(StandardErrorInterface errorCode) {
		super(errorCode);
		// TODO Auto-generated constructor stub
	}

	public InternalServerException(StandardError errorCode, Throwable cause) {
		super(errorCode, cause);
	}
	
	public InternalServerException(String code,String  msg) {
		super(code,msg);
		// TODO Auto-generated constructor stub
	}
}
