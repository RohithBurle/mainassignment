package com.bt.ms.im.exception.handler;

import org.springframework.stereotype.Component;

import com.bt.ms.im.exception.handler.businessexception.RootException;

@Component
public class GenericBusinessExceptionDetails{

	private String errorCode;
	private String errorMessage;
	//private Date timestamp;
	private RootException rootException;
	
	public GenericBusinessExceptionDetails(String errorCode, String errorMessage, RootException rootException) {
		super();
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		//this.timestamp = timestamp;
		this.rootException = rootException;
	}
	public GenericBusinessExceptionDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	
	public RootException getRootEx() {
		return rootException;
	}
	public void setRootEx(RootException rootEx) {
		this.rootException = rootEx;
	}
	@Override
	public String toString() {
		return "StandardException [errorCode=" + errorCode + ", errorMessage=" + errorMessage + "]";
	}
	
}
