package com.bt.ms.im.exception;

public enum InternalServerError implements StandardErrorInterface {

	ERR500_01 ("01", "Internal Server Error");
	

    private final String errorCode;
    private final String errorMessage;

    private InternalServerError(String errorCode, String errorMessage) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    /* (non-Javadoc)
	 * @see com.bt.ms.im.exception.ErrorInterface#getCode()
	 */
    @Override
	public String getCode() {
        return errorCode;
    }

    /* (non-Javadoc)
	 * @see com.bt.ms.im.exception.ErrorInterface#getMessage()
	 */
    @Override
	public String getMessage() {
        return errorMessage;
    }
}

