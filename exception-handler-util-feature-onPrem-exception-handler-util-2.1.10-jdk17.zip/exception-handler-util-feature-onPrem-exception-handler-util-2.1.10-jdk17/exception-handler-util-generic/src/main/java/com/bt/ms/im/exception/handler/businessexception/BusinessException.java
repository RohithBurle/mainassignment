package com.bt.ms.im.exception.handler.businessexception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.bt.ms.im.exception.BusinessError;

@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
public class BusinessException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String errorCode;
	private String errorMessage;

	private RootException rootException;
	
	public BusinessException() {//String errorCode, String errorMessage
		super();
		// TODO Auto-generated constructor stub
	}

	public BusinessException(BusinessError businessError, RootException rootException) {
		this.errorCode = businessError.getErrorCode();
		this.errorMessage = businessError.getErrorMessage();
		this.rootException = rootException;
		// TODO Auto-generated constructor stub
	}
	
	public BusinessException(BusinessError businessError, RootException rootException, Throwable cause) {
		super(businessError.getErrorMessage(), cause);
		this.errorCode = businessError.getErrorCode();
		this.errorMessage = businessError.getErrorMessage();
		this.rootException = rootException;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	
	public RootException getRootException() {
		return rootException;
	}

	public void setRootException(RootException rootException) {
		this.rootException = rootException;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
