package com.bt.ms.im.exception.handler;

import org.springframework.stereotype.Component;

import com.bt.ms.im.exception.StandardError;

@Component
public class GenericStandardExceptionDetails{

	private String code;
	private String message;
	//private Date timestamp;
	
	public GenericStandardExceptionDetails(String errorCode, String errorMessage) {
		super();
		this.code = errorCode;
		this.message = errorMessage;
		//this.timestamp = timestamp;
	}
	public GenericStandardExceptionDetails(StandardError stdError) {
		super();
		this.code = stdError.getCode();
		this.message = stdError.getMessage();
	}
	public GenericStandardExceptionDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getCode() {
		return code;
	}
	public void setCode(String errorCode) {
		this.code = errorCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String errorMessage) {
		this.message = errorMessage;
	}

	@Override
	public String toString() {
		return "StandardException [code=" + code + ", message=" + message + "]";
	}
	
}
