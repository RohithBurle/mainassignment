package com.bt.ms.im.exception.handler.standardexception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.bt.ms.im.exception.StandardError;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class BadRequestException extends StandardException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7483905949983721149L;

	public BadRequestException(StandardError errorCode) {
		super(errorCode);
		// TODO Auto-generated constructor stub
	}
	
	public BadRequestException(String code,String  msg) {
		super(code,msg);
		// TODO Auto-generated constructor stub
	}

	public BadRequestException(StandardError errorCode, Throwable cause) {
		super(errorCode, cause);
	}
}
