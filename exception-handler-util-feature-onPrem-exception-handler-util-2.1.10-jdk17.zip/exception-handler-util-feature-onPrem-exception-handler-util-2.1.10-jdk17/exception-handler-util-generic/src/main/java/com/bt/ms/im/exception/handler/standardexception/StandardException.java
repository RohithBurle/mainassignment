package com.bt.ms.im.exception.handler.standardexception;

import com.bt.ms.im.exception.StandardErrorInterface;

public abstract class StandardException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String code;
	private String message;

	
	public StandardException() {//String code, String message
		super();
		// TODO Auto-generated constructor stub
	}

	
	public StandardException(StandardErrorInterface errorCode) {//String code, String message
		this.code = errorCode.getCode();
		this.message = errorCode.getMessage();
		// TODO Auto-generated constructor stub
	}
	
	public StandardException(StandardErrorInterface errorCode, Throwable cause) {
		super(errorCode.getMessage(), cause);
		this.code = errorCode.getCode();
		this.message = errorCode.getMessage();
	}
	
	public StandardException(String code,String  msg) {//String code, String message
		this.code = code;
		this.message = msg;
		// TODO Auto-generated constructor stub
	}

	public String getCode() {
		return code;
	}

	public void setCode(String errorCode) {
		this.code = errorCode;
	}

	public String getErrorMessage() {
		return message;
	}

	public void setErrorMessage(String errorMessage) {
		this.message = errorMessage;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
