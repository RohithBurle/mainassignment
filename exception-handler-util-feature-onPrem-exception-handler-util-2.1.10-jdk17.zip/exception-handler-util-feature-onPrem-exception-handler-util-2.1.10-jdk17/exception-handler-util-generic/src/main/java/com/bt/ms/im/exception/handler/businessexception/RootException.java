package com.bt.ms.im.exception.handler.businessexception;

public class RootException {

	private String system;
	private String reasonCode;
	private String reasonText;
	
	public RootException(String system, String reasonCode, String reasonText) {
		super();
		this.system = system;
		this.reasonCode = reasonCode;
		this.reasonText = reasonText;
	}
	public RootException() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getSystem() {
		return system;
	}
	public void setSystem(String system) {
		this.system = system;
	}
	public String getReasonCode() {
		return reasonCode;
	}
	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}
	public String getReasonText() {
		return reasonText;
	}
	public void setReasonText(String reasonText) {
		this.reasonText = reasonText;
	}
	@Override
	public String toString() {
		return "RootException [system=" + system + ", reasonCode=" + reasonCode + ", reasonText=" + reasonText + "]";
	}
	
}
