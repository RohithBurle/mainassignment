package com.bt.ms.im.exception;

public enum BusinessError {

	
	ERR500_02 ("02", "Internal Server Error");

    private final String errorCode;
    private final String errorMessage;

    private BusinessError(String errorCode, String errorMessage) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }
}

