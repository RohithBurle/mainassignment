package com.bt.ms.im.baseclientexception;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaseClientException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3422273623562293457L;
	private String reasonCode;
	private String reasonText;
	private String sourceSystem;
	
	
}
